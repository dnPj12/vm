const mysql = require('mysql2');
require('dotenv').config();

// Membuat pool koneksi ke MariaDB
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Menggunakan promise agar nanti query bisa pakai async/await
const db = pool.promise();

// Test koneksi saat file ini dipanggil
pool.getConnection((err, connection) => {
    if (err) {
        console.error('Gagal konek ke MariaDB:', err.message);
    } else {
        console.log('Koneksi ke MariaDB berhasil!');
        connection.release();
    }
});

module.exports = db;
