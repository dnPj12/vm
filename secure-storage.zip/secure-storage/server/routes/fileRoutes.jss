const express = require('express');
const multer = require('multer');
const { google } = require('googleapis');
const stream = require('stream');
const jwt = require('jsonwebtoken');
const db = require('../config/db'); // Sesuaikan dengan path database lu
const router = express.Router();

const upload = multer({ storage: multer.memoryStorage() });

// --- MIDDLEWARE CEK TOKEN ---
const cekToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader) return res.status(403).json({ message: 'Akses ditolak, token nggak ada bung!' });
    
    const token = authHeader.split(' ')[1]; 
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded; // Berisi { id, username }
        next();
    } catch (err) {
        return res.status(401).json({ message: 'Token tidak valid atau expired!' });
    }
};

// --- SETUP GOOGLE DRIVE (OAUTH 2.0) ---
const oauth2Client = new google.auth.OAuth2(
    process.env.GDRIVE_CLIENT_ID,
    process.env.GDRIVE_CLIENT_SECRET,
    'https://developers.google.com/oauthplayground'
);

oauth2Client.setCredentials({
    refresh_token: process.env.GDRIVE_REFRESH_TOKEN
});

const driveService = google.drive({ version: 'v3', auth: oauth2Client });

// --- ENDPOINT UPLOAD ---
router.post('/upload', cekToken, upload.single('file'), async (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ message: 'File tidak ditemukan!' });

        // 1. Tangkap folderId dari body request frontend
        const { encryptedName, encryptedThumbnail, originalNameEncrypted, folderId } = req.body;
        const userId = req.user.id;

        const bufferStream = new stream.PassThrough();
        bufferStream.end(req.file.buffer);

        console.log(`Mulai upload ${encryptedName} ke GDrive pakai OAuth...`);

        const driveResponse = await driveService.files.create({
            requestBody: {
                name: encryptedName,
                parents: [process.env.GDRIVE_FOLDER_ID],
            },
            media: {
                mimeType: 'application/octet-stream',
                body: bufferStream,
            },
            fields: 'id',
        });

        const gdriveFileId = driveResponse.data.id;

        // 2. Validasi posisi folderId sebelum masuk database
        const finalFolderId = (folderId && folderId !== 'null') ? folderId : null;

        // 3. Masukkan kolom folder_id ke dalam query INSERT
        await db.execute(
            'INSERT INTO files (user_id, gdrive_file_id, encrypted_name, original_name_encrypted, encrypted_thumbnail, folder_id) VALUES (?, ?, ?, ?, ?, ?)',
            [userId, gdriveFileId, encryptedName, originalNameEncrypted, encryptedThumbnail || null, finalFolderId]
        );

        res.json({ message: 'File aman tersimpan di brankas GDrive!', fileId: gdriveFileId });

    } catch (error) {
        console.error('Error saat proses upload:', error.message);
        res.status(500).json({ message: 'Gagal upload ke Drive bung.' });
    }
});

// --- ENDPOINT LIHAT DAFTAR FILE ---
router.get('/list', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const folderId = req.query.folderId;

        // Bikin query dinamis biar MariaDB gak bingung
        let query = 'SELECT id, gdrive_file_id, encrypted_name, original_name_encrypted, encrypted_thumbnail, created_at FROM files WHERE user_id = ?';
        let params = [userId];

        if (folderId && folderId !== 'null') {
            query += ' AND folder_id = ?';
            params.push(folderId);
        } else {
            query += ' AND folder_id IS NULL';
        }

        const [rows] = await db.execute(query, params);
        res.json(rows);
    } catch (error) {
        console.error('Error saat fetch list file:', error.message);
        res.status(500).json({ message: 'Gagal mengambil daftar file bung.' });
    }
});

// --- ENDPOINT True RECENT ACTIVITY (Untuk Halaman Home) ---
router.get('/recent', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;

        // Ambil semua file milik user, urutkan dari yang paling baru (DESC)
        const [rows] = await db.execute(
            'SELECT id, gdrive_file_id, encrypted_name, original_name_encrypted, encrypted_thumbnail, created_at FROM files WHERE user_id = ? ORDER BY created_at DESC',
            [userId]
        );
        res.json(rows);
    } catch (error) {
        console.error('Error saat fetch recent files:', error.message);
        res.status(500).json({ message: 'Gagal mengambil aktivitas terbaru bung.' });
    }
});

// --- GERBANG AMAN: ENDPOINT DOWNLOAD (SINGLE PASSWORD) ---
router.post('/download/:id', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const fileId = req.params.id;

        // Satpam Lapis 1: Cek Kepemilikan di MariaDB
        const [files] = await db.execute(
            'SELECT gdrive_file_id, encrypted_name FROM files WHERE id = ? AND user_id = ?', 
            [fileId, userId]
        );
        
        if (files.length === 0) {
            return res.status(403).json({ message: 'Akses ditolak! Ini bukan file lu bung.' });
        }

        const fileData = files[0];
        console.log(`Izin diberikan! Menarik ${fileData.encrypted_name} dari GDrive...`);

        // Tarik biner asli dari GDrive
        const driveRes = await driveService.files.get(
            { fileId: fileData.gdrive_file_id, alt: 'media' },
            { responseType: 'stream' }
        );

        // Alirkan langsung ke frontend sebagai octet-stream
        res.setHeader('Content-Disposition', `attachment; filename=${fileData.encrypted_name}`);
        res.setHeader('Content-Type', 'application/octet-stream');
        
        driveRes.data.pipe(res);

    } catch (error) {
        console.error('Error saat download:', error.message);
        res.status(500).json({ message: 'Gagal menarik file dari GDrive.' });
    }
});

// --- ENDPOINT HAPUS FILE ---
router.delete('/:id', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const fileId = req.params.id;

        // 1. Cek kepemilikan dan ambil ID GDrive (Satpam Lapis 1)
        const [files] = await db.execute('SELECT gdrive_file_id FROM files WHERE id = ? AND user_id = ?', [fileId, userId]);
        if (files.length === 0) {
            return res.status(403).json({ message: 'Akses ditolak! File tidak ditemukan atau bukan milik lu.' });
        }

        const gdriveFileId = files[0].gdrive_file_id;

        // 2. Hapus biner dari Google Drive
        await driveService.files.delete({ fileId: gdriveFileId });

        // 3. Hapus rekam jejak dari MariaDB
        await db.execute('DELETE FROM files WHERE id = ?', [fileId]);

        res.json({ message: 'File berhasil dibumihanguskan dari brankas!' });
    } catch (error) {
        console.error('Error saat hapus file:', error.message);
        res.status(500).json({ message: 'Gagal menghapus file dari GDrive.' });
    }
});

module.exports = router;

