const express = require('express');
const router = express.Router();
const multer = require('multer');
const { google } = require('googleapis');
const stream = require('stream');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

// --- MIDDLEWARE CEK TOKEN (SAMA KAYAK SEBELUMNYA) ---
const cekToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader) return res.status(430).json({ message: 'Akses ditolak bung!' });
    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded; 
        next();
    } catch (err) {
        return res.status(401).json({ message: 'Token hangus!' });
    }
};

// --- KONFIGURASI GDRIVE (SAMA KAYAK SEBELUMNYA) ---
const oauth2Client = new google.auth.OAuth2(
    process.env.GDRIVE_CLIENT_ID,
    process.env.GDRIVE_CLIENT_SECRET,
    process.env.GDRIVE_REDIRECT_URI
);
oauth2Client.setCredentials({ refresh_token: process.env.GDRIVE_REFRESH_TOKEN });
const driveService = google.drive({ version: 'v3', auth: oauth2Client });

const upload = multer({ storage: multer.memoryStorage() });

// --- [ENDPOINT BARU] 1. AMBIL DAFTAR FILE TER-SAVED ---
router.get('/saved', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        // Query JOIN: Ambil data file (f.*) dari tabel files yang ada di tabel saved_files (sf) milik user ini
        const [rows] = await db.execute(
            `SELECT f.*, sf.saved_at 
             FROM files f 
             JOIN saved_files sf ON f.id = sf.file_id 
             WHERE sf.user_id = ? 
             ORDER BY sf.saved_at DESC`,
            [userId]
          );
        res.json(rows);
    } catch (error) {
        console.error('Error fetch saved:', error.message);
        res.status(500).json({ message: 'Gagal mengambil daftar bookmark bung.' });
    }
});

// --- [ENDPOINT BARU] 2. TAMBAH KE SAVED (BOOKMARK) ---
router.post('/save/:fileId', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const fileId = req.params.fileId;
        // Pake INSERT IGNORE biar gak error kalau user mencet save dua kali cepet banget
        await db.execute(
            'INSERT IGNORE INTO saved_files (user_id, file_id) VALUES (?, ?)',
            [userId, fileId]
        );
        res.json({ message: 'File berhasil disimpan di bookmark bung!' });
    } catch (error) {
        res.status(500).json({ message: 'Gagal nge-bookmark file.' });
    }
});

// --- [ENDPOINT BARU] 3. HAPUS DARI SAVED ---
router.delete('/save/:fileId', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const fileId = req.params.fileId;
        await db.execute(
            'DELETE FROM saved_files WHERE user_id = ? AND file_id = ?',
            [userId, fileId]
        );
        res.json({ message: 'File dihapus dari bookmark.' });
    } catch (error) {
        res.status(500).json({ message: 'Gagal menghapus bookmark.' });
    }
});

// --- ENDPOINT UPLOAD (UPDATE: NANGKEP FOLDERID) ---
router.post('/upload', cekToken, upload.single('file'), async (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ message: 'File gak ada bung!' });
        const { encryptedName, encryptedThumbnail, originalNameEncrypted, folderId } = req.body;
        const userId = req.user.id;
        const bufferStream = new stream.PassThrough();
        bufferStream.end(req.file.buffer);
        console.log(`Upload ${encryptedName} ke GDrive...`);
        const driveResponse = await driveService.files.create({
            requestBody: { name: encryptedName, parents: [process.env.GDRIVE_FOLDER_ID] },
            media: { mimeType: 'application/octet-stream', body: bufferStream },
            fields: 'id',
        });
        const gdriveFileId = driveResponse.data.id;
        const finalFolderId = (folderId && folderId !== 'null') ? folderId : null;
        await db.execute(
            'INSERT INTO files (user_id, gdrive_file_id, encrypted_name, original_name_encrypted, encrypted_thumbnail, folder_id) VALUES (?, ?, ?, ?, ?, ?)',
            [userId, gdriveFileId, encryptedName, originalNameEncrypted, encryptedThumbnail || null, finalFolderId]
        );
        res.json({ message: 'File aman tersimpan di GDrive!', fileId: gdriveFileId });
    } catch (error) {
        console.error('Error upload:', error.message);
        res.status(500).json({ message: 'Gagal upload bung.' });
    }
});

// --- ENDPOINT True RECENT ACTIVITY (Untuk Halaman Home) ---
router.get('/recent', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        // Gw update query-nya bung biar ngasih tau status 'is_saved' (1=saved, 0=belom)
        const [rows] = await db.execute(
            `SELECT f.*, 
                    (SELECT COUNT(*) FROM saved_files sf WHERE sf.file_id = f.id AND sf.user_id = ?) as is_saved
             FROM files f 
             WHERE f.user_id = ? 
             ORDER BY f.created_at DESC LIMIT 20`,
            [userId, userId]
        );
        res.json(rows);
    } catch (error) {
        console.error('Error fetch recent:', error.message);
        res.status(500).json({ message: 'Gagal ambil aktivitas terbaru.' });
    }
});

// --- LIST FILE DALAM FOLDER (UPDATE: NANGKEP FOLDERID DINAMIS & STATUS SAVED) ---
router.get('/list', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const folderId = req.query.folderId;
        const finalFolderId = (folderId && folderId !== 'null') ? folderId : null;
        // Query dinamis untuk folderId NULL (root) atau folder spesifik + status 'is_saved'
        const query = finalFolderId 
            ? `SELECT f.*, (SELECT COUNT(*) FROM saved_files sf WHERE sf.file_id = f.id AND sf.user_id = ?) as is_saved FROM files f WHERE f.user_id = ? AND f.folder_id = ? ORDER BY f.created_at DESC`
            : `SELECT f.*, (SELECT COUNT(*) FROM saved_files sf WHERE sf.file_id = f.id AND sf.user_id = ?) as is_saved FROM files f WHERE f.user_id = ? AND f.folder_id IS NULL ORDER BY f.created_at DESC`;
        
        const params = finalFolderId ? [userId, userId, finalFolderId] : [userId, userId];
        const [rows] = await db.execute(query, params);
        res.json(rows);
    } catch (error) {
        console.error('Error list files:', error.message);
        res.status(500).json({ message: 'Gagal list file bung.' });
    }
});

// --- ENDPOINT DOWNLOAD & DELETE (SAMA KAYAK SEBELUMNYA) ---
router.post('/download/:fileId', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const fileId = req.params.fileId;
        const [rows] = await db.execute('SELECT gdrive_file_id FROM files WHERE id = ? AND user_id = ?', [fileId, userId]);
        if (rows.length === 0) return res.status(403).json({ message: 'Akses biner ditolak satpam server!' });
        const gdriveFileId = rows[0].gdrive_file_id;
        console.log(`Menarik file ${gdriveFileId} dari Drive...`);
        const response = await driveService.files.get({ fileId: gdriveFileId, alt: 'media' }, { responseType: 'stream' });
        res.setHeader('Content-Type', 'application/octet-stream');
        response.data.pipe(res);
    } catch (error) {
        console.error('Error download:', error.message);
        res.status(500).json({ message: 'Gagal tarik file.' });
    }
});

router.delete('/:fileId', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const fileId = req.params.fileId;
        const [rows] = await db.execute('SELECT gdrive_file_id FROM files WHERE id = ? AND user_id = ?', [fileId, userId]);
        if (rows.length === 0) return res.status(403).json({ message: 'Gak berhak hapus file ini bung!' });
        const gdriveFileId = rows[0].gdrive_file_id;
        console.log(`Hapus file ${gdriveFileId} dari Drive...`);
        await driveService.files.delete({ fileId: gdriveFileId });
        await db.execute('DELETE FROM files WHERE id = ?', [fileId]);
        res.json({ message: 'File sukses dibumihanguskan!' });
    } catch (error) {
        console.error('Error delete:', error.message);
        res.status(500).json({ message: 'Gagal hapus file bung.' });
    }
});

module.exports = router;
