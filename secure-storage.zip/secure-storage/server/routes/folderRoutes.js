const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken'); // Tambahkan ini di atas
const db = require('../config/db'); 

// --- MIDDLEWARE CEK TOKEN (Copy dari fileRoutes) ---
const cekToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    if (!authHeader) return res.status(403).json({ message: 'Akses ditolak, token nggak ada bung!' });

    const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded; 
        next();
    } catch (err) {
        return res.status(401).json({ message: 'Token tidak valid atau expired!' });
    }
};

// --- 1. BUAT FOLDER BARU ---
router.post('/', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const { encryptedName, parentId } = req.body; 

        if (!encryptedName) {
            return res.status(400).json({ message: 'Nama folder wajib ada bung.' });
        }

        // TAMBAHKAN 'const [result] =' DI SINI BUNG!
        const [result] = await db.execute(
            'INSERT INTO folders (user_id, parent_id, encrypted_name) VALUES (?, ?, ?)',
            [userId, parentId || null, encryptedName]
        );

console.log(`[CCTV BACKEND] Folder sukses di-insert! ID foldernya adalah:`, result.insertId);

        // KEMBALIKAN insertId KE FRONTEND
        res.status(201).json({
            message: 'Folder baru berhasil dibuat!',
            folderId: result.insertId
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Gagal membuat folder di server.' });
    }
});

// --- 2. AMBIL DAFTAR FOLDER DI DIREKTORI AKTIF ---
router.get('/', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const parentId = req.query.parentId;

        let query = 'SELECT id, parent_id, encrypted_name FROM folders WHERE user_id = ?';
        let params = [userId];

        if (parentId && parentId !== 'null') {
            query += ' AND parent_id = ?';
            params.push(parentId);
        } else {
            query += ' AND parent_id IS NULL';
        }

        const [folders] = await db.execute(query, params);
        res.json(folders);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Gagal mengambil daftar folder.' });
    }
});

// --- 3. HAPUS FOLDER (OPSI 1: HARUS KOSONG) ---
router.delete('/:id', cekToken, async (req, res) => {
    try {
        const userId = req.user.id;
        const folderId = req.params.id;

        // 1. Cek apakah folder ini milik user yang lagi login
        const [folder] = await db.execute('SELECT id FROM folders WHERE id = ? AND user_id = ?', [folderId, userId]);
        if (folder.length === 0) {
            return res.status(403).json({ error: 'Gagal: Folder tidak ditemukan atau bukan milik lu bung.' });
        }

        // 2. Cek apakah ada file di dalam folder ini
        const [files] = await db.execute('SELECT id FROM files WHERE folder_id = ?', [folderId]);
        if (files.length > 0) {
            return res.status(400).json({ error: 'Gagal: Folder masih berisi file bung. Kosongkan dulu.' });
        }

        // 3. Cek apakah ada sub-folder di dalam folder ini
        const [subFolders] = await db.execute('SELECT id FROM folders WHERE parent_id = ?', [folderId]);
        if (subFolders.length > 0) {
            return res.status(400).json({ error: 'Gagal: Folder masih berisi sub-folder bung. Kosongkan dulu.' });
        }

        // 4. Lolos semua ujian, eksekusi hapus!
        await db.execute('DELETE FROM folders WHERE id = ?', [folderId]);
        res.json({ message: 'Folder berhasil dihapus.' });

    } catch (error) {
        console.error('Error delete folder:', error.message);
        res.status(500).json({ error: 'Server gagal menghapus folder.' });
    }
});

module.exports = router;
