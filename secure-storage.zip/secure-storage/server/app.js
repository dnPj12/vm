const express = require('express');
const cors = require('cors');
require('dotenv').config();

const db = require('./config/db');

// Panggil rute-rute aplikasi
const authRoutes = require('./routes/authRoutes');
const fileRoutes = require('./routes/fileRoutes'); 
const folderRoutes = require('./routes/folderRoutes'); // 1. TAMBAHKAN INI BUNG

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json()); 

// Mendaftarkan rute API
app.use('/api/auth', authRoutes);
app.use('/api/files', fileRoutes); 
app.use('/api/folders', folderRoutes); // 2. TAMBAHKAN INI JUGA

app.get('/', (req, res) => {
    res.json({ message: 'Backend Secure Storage siap tempur!' });
});

app.listen(PORT, () => {
    console.log(`Server backend jalan di port ${PORT}`);
});
