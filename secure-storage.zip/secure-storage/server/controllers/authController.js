const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

// --- FITUR REGISTER ---
const register = async (req, res) => {
    try {
        const { username, password } = req.body;

        // --- TAMBAHKAN SATPAM REGEX DI SINI BUNG ---
        const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{12,}$/;
        if (!strongPasswordRegex.test(password)) {
            return res.status(400).json({ 
                message: 'Akses ditolak! Password tidak memenuhi standar keamanan militer.' 
            });
        }

        // Cek apakah username sudah ada
        const [existingUser] = await db.execute('SELECT * FROM users WHERE username = ?', [username]);
        if (existingUser.length > 0) {
            return res.status(400).json({ message: 'Username sudah dipakai bung!' });
        }

        // Amankan password (hashing)
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Simpan ke database MariaDB
        const [result] = await db.execute(
            'INSERT INTO users (username, password_hash) VALUES (?, ?)', 
            [username, hashedPassword]
        );

        res.status(201).json({ message: 'Register berhasil!', userId: result.insertId });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Terjadi kesalahan di server.' });
    }
};

// --- FITUR LOGIN ---
const login = async (req, res) => {
    try {
        const { username, password } = req.body;

        // Cari user di database
        const [users] = await db.execute('SELECT * FROM users WHERE username = ?', [username]);
        if (users.length === 0) {
            return res.status(400).json({ message: 'Username tidak ditemukan.' });
        }

        const user = users[0];

        // Cek apakah password cocok
        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) {
            return res.status(400).json({ message: 'Password salah bung!' });
        }

        // Buat token JWT yang berlaku 1 hari
        const token = jwt.sign(
            { id: user.id, username: user.username }, 
            process.env.JWT_SECRET, 
            { expiresIn: '1d' }
        );

        res.json({ message: 'Login sukses!', token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Terjadi kesalahan di server.' });
    }
};

module.exports = { register, login };
