import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaEye, FaEyeSlash } from 'react-icons/fa';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isLogin) {
      const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{12,}$/;
      if (!strongPasswordRegex.test(password)) {
        return alert('Password terlalu lemah! Wajib minimal 12 karakter, mengandung huruf besar, huruf kecil, angka, dan simbol (contoh: @$!%*?&).');
      }
    }

    const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';
    
    try {
      const res = await fetch(`${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });

      const data = await res.json();

      if (res.ok) {
        if (isLogin) {
          localStorage.setItem('token', data.token);
          sessionStorage.setItem('vaultKey', password);
          navigate('/home'); 
        } else {
          setMessage('Register sukses! Silakan login.');
          setIsLogin(true);
          setPassword('');
          setShowPassword(false);
        }
      } else {
        setMessage(data.message || 'Terjadi kesalahan');
      }
    } catch (err) {
      setMessage('Gagal menghubungi server backend');
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#f9fafb', padding: '20px', boxSizing: 'border-box' }}>
      
      <div style={{ backgroundColor: 'white', padding: '48px 40px', borderRadius: '16px', boxShadow: '0 4px 20px rgba(0, 0, 0, 0.05)', width: '100%', maxWidth: '400px' }}>
        
        {/* IMPLEMENTASI: text-h1 */}
        <h2 className="text-h1" style={{ textAlign: 'center', marginBottom: '40px', color: '#111827', letterSpacing: '-0.5px' }}>
          {isLogin ? 'Login' : 'Sign Up'}
        </h2>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
          
          <div style={{ position: 'relative' }}>
            {/* IMPLEMENTASI: text-body2 */}
            <input
              type="text"
              placeholder="Username / Email"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className="text-body2"
              style={{ width: '100%', padding: '8px 0', border: 'none', borderBottom: '1px solid #d1d5db', outline: 'none', color: '#1f2937', backgroundColor: 'transparent', boxSizing: 'border-box' }}
            />
          </div>

          <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
            {/* IMPLEMENTASI: text-body2 */}
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="text-body2"
              style={{ width: '100%', padding: '8px 30px 8px 0', border: 'none', borderBottom: '1px solid #d1d5db', outline: 'none', color: '#1f2937', backgroundColor: 'transparent', boxSizing: 'border-box' }}
            />
            
            <div 
              onClick={() => setShowPassword(!showPassword)}
              style={{ position: 'absolute', right: 0, cursor: 'pointer', color: '#9ca3af', display: 'flex', alignItems: 'center', paddingBottom: '4px' }}
            >
              {showPassword ? <FaEyeSlash size={18} /> : <FaEye size={18} />}
            </div>
          </div>

          {/* IMPLEMENTASI: text-button */}
          <button type="submit" className="text-button" style={{ marginTop: '12px', padding: '14px', borderRadius: '8px', backgroundColor: '#3b82f6', color: 'white', border: 'none', cursor: 'pointer', boxShadow: '0 4px 12px rgba(59, 130, 246, 0.25)', transition: 'background-color 0.2s' }}>
            {isLogin ? 'Login' : 'Sign up'}
          </button>
        </form>

        {/* IMPLEMENTASI: text-caption1-md untuk pesan error/sukses */}
        {message && <p className="text-caption1-md" style={{ color: '#ef4444', textAlign: 'center', marginTop: '20px' }}>{message}</p>}

        {/* IMPLEMENTASI: text-button untuk area switch login/register */}
        <div className="text-button" style={{ textAlign: 'center', marginTop: '32px', color: '#6b7280' }}>
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <span
            onClick={() => { setIsLogin(!isLogin); setMessage(''); }}
            style={{ color: '#3b82f6', cursor: 'pointer', fontWeight: '600' }}
          >
            {isLogin ? 'Sign up' : 'Login'}
          </span>
        </div>

      </div>
    </div>
  );
}
