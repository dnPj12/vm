import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FaUserCircle,
  FaMoon,
  FaSun,
  FaSignOutAlt,
  FaChevronRight,
  FaShieldAlt,
  FaInfoCircle
} from 'react-icons/fa';

export default function Settings() {
  const navigate = useNavigate();
  const [isDarkMode, setIsDarkMode] = useState(false);

  const handleLogout = () => {
    if (!window.confirm('Yakin mau mengunci brankas dan keluar bung?')) return;

    localStorage.removeItem('token');
    sessionStorage.removeItem('vaultKey');
    navigate('/');
  };

  return (
    <div style={{ marginTop: '8px', paddingBottom: '20px' }}>

      {/* IMPLEMENTASI: text-h2 */}
      <h3 className="text-h2" style={{ margin: 0, color: '#1f2937', marginBottom: '20px' }}>
        Settings
      </h3>

      {/* 1. KARTU PROFIL */}
      <div style={{ backgroundColor: 'white', padding: '16px', borderRadius: '16px', border: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', cursor: 'pointer' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <FaUserCircle size={48} color="#9ca3af" />
          <div style={{ display: 'flex', flexDirection: 'column' }}>

            {/* IMPLEMENTASI: text-body2-md */}
            <span className="text-body2-md" style={{ color: '#1f2937' }}>Agen Rahasia</span>

            {/* IMPLEMENTASI: text-caption1 */}
            <span className="text-caption1" style={{ color: '#6b7280', marginTop: '2px' }}>Kelola profil & keamanan</span>
          </div>
        </div>
        <FaChevronRight size={14} color="#9ca3af" />
      </div>

      {/* 2. PREFERENSI APLIKASI */}

      {/* IMPLEMENTASI: text-caption1-md */}
      <h4 className="text-caption1-md" style={{ color: '#6b7280', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px', marginLeft: '8px', marginTop: 0 }}>
        Preferensi
      </h4>

      <div style={{ backgroundColor: 'white', borderRadius: '16px', border: '1px solid #e5e7eb', overflow: 'hidden', marginBottom: '24px' }}>

        {/* Menu Tema Gelap/Terang */}
        <div style={{ padding: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #f3f4f6' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ padding: '8px', backgroundColor: '#f3f4f6', borderRadius: '8px', display: 'flex' }}>
              {isDarkMode ? <FaMoon size={16} color="#4b5563" /> : <FaSun size={16} color="#f59e0b" />}
            </div>
            {/* IMPLEMENTASI: text-button */}
            <span className="text-button" style={{ color: '#374151' }}>Dark Mode</span>
          </div>

          <div
            onClick={() => setIsDarkMode(!isDarkMode)}
            style={{ width: '44px', height: '24px', backgroundColor: isDarkMode ? '#10b981' : '#d1d5db', borderRadius: '12px', position: 'relative', cursor: 'pointer', transition: 'background-color 0.3s' }}
          >
            <div style={{ width: '20px', height: '20px', backgroundColor: 'white', borderRadius: '50%', position: 'absolute', top: '2px', left: isDarkMode ? '22px' : '2px', transition: 'left 0.3s', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }} />
          </div>
        </div>

        {/* Menu Keamanan */}
        <div style={{ padding: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #f3f4f6', cursor: 'pointer' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ padding: '8px', backgroundColor: '#f3f4f6', borderRadius: '8px', display: 'flex' }}>
              <FaShieldAlt size={16} color="#3b82f6" />
            </div>
            {/* IMPLEMENTASI: text-button */}
            <span className="text-button" style={{ color: '#374151' }}>Ubah Kunci Brankas</span>
          </div>
          <FaChevronRight size={14} color="#9ca3af" />
        </div>

        {/* Menu Tentang Aplikasi - SUDAH DI-HOOK KE /about BUNG */}
        <div
          onClick={() => navigate('/about')}
          style={{ padding: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ padding: '8px', backgroundColor: '#f3f4f6', borderRadius: '8px', display: 'flex' }}>
              <FaInfoCircle size={16} color="#8b5cf6" />
            </div>
            {/* IMPLEMENTASI: text-button */}
            <span className="text-button" style={{ color: '#374151' }}>Tentang niyStorage</span>
          </div>
          <FaChevronRight size={14} color="#9ca3af" />
        </div>

      </div>

      {/* 3. DANGER ZONE (LOGOUT) */}

      {/* IMPLEMENTASI: text-caption1-md */}
      <h4 className="text-caption1-md" style={{ color: '#ef4444', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px', marginLeft: '8px', marginTop: 0 }}>
        Zona Berbahaya
      </h4>

      <div style={{ backgroundColor: 'white', borderRadius: '16px', border: '1px solid #fca5a5', overflow: 'hidden' }}>
        <div
          onClick={handleLogout}
          style={{ padding: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', cursor: 'pointer', backgroundColor: '#fef2f2' }}
        >
          <FaSignOutAlt size={18} color="#ef4444" />
          {/* IMPLEMENTASI: text-body2-md (TYPO DIPERBAIKI) */}
          <span className="text-body2-md" style={{ color: '#ef4444' }}>Kunci & Keluar</span>
        </div>
      </div>

    </div>
  );
}
