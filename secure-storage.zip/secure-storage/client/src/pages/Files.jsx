import { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { decryptText, decryptFile, encryptText } from '../utils/crypto';
import { FaFolder, FaFileAlt, FaLock, FaDownload, FaTrash, FaEllipsisV, FaThLarge, FaList, FaArrowLeft, FaFolderPlus, FaBookmark, FaRegBookmark } from 'react-icons/fa';

export default function Files() {
  const { searchQuery, currentFolderId, setCurrentFolderId, refreshKey, openPreview } = useOutletContext();

  const [files, setFiles] = useState([]);
  const [folders, setFolders] = useState([]);
  const [parentHistory, setParentHistory] = useState([]);

  const [viewMode, setViewMode] = useState(() => {
    return localStorage.getItem('viewModePref') || 'list';
  });

  // 2. Simpan ke memori otomatis setiap kali tombol grid/list diklik
  useEffect(() => {
    localStorage.setItem('viewModePref', viewMode);
  }, [viewMode]);

  const [activeMenuId, setActiveMenuId] = useState(null);
  const [activeFolderMenuId, setActiveFolderMenuId] = useState(null);
  const [message, setMessage] = useState('');

  const [decryptedThumbnails, setDecryptedThumbnails] = useState({});
  const [decryptedNames, setDecryptedNames] = useState({});
  const [decryptedFolderNames, setDecryptedFolderNames] = useState({});

  const token = localStorage.getItem('token');
  const vaultKey = sessionStorage.getItem('vaultKey');

  const fetchFolderAndFiles = async () => {
    try {
      const resFolder = await fetch(`/api/folders?parentId=${currentFolderId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const resFile = await fetch(`/api/files/list?folderId=${currentFolderId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (resFolder.ok && resFile.ok) {
        const folderData = await resFolder.json();
        const fileData = await resFile.json();

        setFolders(folderData);
        setFiles(fileData);

        const newDecryptedThumbnails = {};
        const newDecryptedNames = {};
        const newDecryptedFolderNames = {};

        if (vaultKey) {
          for (const folder of folderData) {
            try {
              if (folder.encrypted_name) {
                const realFolderName = await decryptText(folder.encrypted_name, vaultKey);
                newDecryptedFolderNames[folder.id] = realFolderName || 'Folder Tanpa Nama';
              }
            } catch (err) {
              newDecryptedFolderNames[folder.id] = '⚠️ Folder Korup';
            }
          }

          for (const file of fileData) {
            try {
              if (file.original_name_encrypted) {
                const realName = await decryptText(file.original_name_encrypted, vaultKey);
                newDecryptedNames[file.id] = realName || 'File Tanpa Nama';
              }
            } catch (err) {
              newDecryptedNames[file.id] = '⚠️ Kunci Salah / Korup';
            }

            try {
              if (file.encrypted_thumbnail) {
                const decryptedThumb = await decryptText(file.encrypted_thumbnail, vaultKey);
                if (decryptedThumb) newDecryptedThumbnails[file.id] = decryptedThumb;
              }
            } catch (err) {
              console.warn(`Gagal dekripsi thumbnail file ID ${file.id}`);
            }
          }
        }

        setDecryptedFolderNames(newDecryptedFolderNames);
        setDecryptedThumbnails(newDecryptedThumbnails);
        setDecryptedNames(newDecryptedNames);
      }
    } catch (err) {
      console.error('Gagal memuat data explorer:', err);
    }
  };

  useEffect(() => {
    fetchFolderAndFiles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentFolderId, refreshKey]);

  useEffect(() => {
    const handleOutsideClick = () => { setActiveMenuId(null);
    setActiveFolderMenuId(null); }
    window.addEventListener('click', handleOutsideClick);
    return () => window.removeEventListener('click', handleOutsideClick);
  }, []);

  const handleCreateFolder = async () => {
    const folderName = prompt("Masukkan nama folder rahasia baru:");
    if (!folderName) return;

    const encryptedFolderName = await encryptText(folderName, vaultKey);

    try {
      const res = await fetch('/api/folders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          encryptedName: encryptedFolderName,
          parentId: currentFolderId
        })
      });

      if (res.ok) {
        fetchFolderAndFiles();
      } else {
        alert("Gagal membuat folder!");
      }
    } catch (err) {
      alert("Gagal membuat folder, jaringan error.");
    }
  };

  const handleEnterFolder = (folderId) => {
    setParentHistory([...parentHistory, currentFolderId]);
    setCurrentFolderId(folderId); 
  };

  const handleGoBack = () => {
    const newHistory = [...parentHistory];
    const prevFolderId = newHistory.pop() || null;
    setParentHistory(newHistory);
    setCurrentFolderId(prevFolderId); 
  };

  const handleDownloadFile = async (fileId, encryptedName, originalNameEncrypted) => {
    setMessage('Menarik biner terenkripsi...');
    try {
      const res = await fetch(`/api/files/download/${fileId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      if (!res.ok) return alert('Akses ditolak server!');

      const encryptedBlob = await res.blob();
      const decryptedBlob = await decryptFile(encryptedBlob, vaultKey);
      const originalName = await decryptText(originalNameEncrypted, vaultKey) || 'file_rahasia';

      const downloadUrl = window.URL.createObjectURL(decryptedBlob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', originalName);
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
      setMessage('');
    } catch (err) {
      alert('Gagal mendekripsi file biner. Kunci mungkin salah.');
      setMessage('');
    }
  };

  // --- FUNGSI TOGGLE SAVE / UNSAVE ---
  const handleToggleSave = async (fileId, isSaved) => {
    try {
      const method = isSaved ? 'DELETE' : 'POST';
      const res = await fetch(`/api/files/save/${fileId}`, {
        method,
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (res.ok) {
        fetchFolderAndFiles(); // Refresh UI biar data is_saved yg baru ke-load
      }
    } catch (err) {
      alert('Gagal mengubah status bookmark.');
    }
  };

  const handleDelete = async (fileId) => {
    if (!window.confirm('Hapus file ini permanen dari brankas bung?')) return;
    try {
      const res = await fetch(`/api/files/${fileId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        fetchFolderAndFiles();
      }
    } catch (err) {
      alert('Gagal menghapus file.');
    }
  };

  const handleDeleteFolder = async (folderId) => {
    if (!window.confirm('Yakin mau menghapus folder ini bung? (Pastikan isinya sudah dikosongkan)')) return;
    
    try {
      const res = await fetch(`/api/folders/${folderId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (res.ok) {
        fetchFolderAndFiles(); // Refresh UI
      } else {
        const data = await res.json();
        alert(data.error); // Menampilkan pesan penolakan dari backend
      }
    } catch (err) {
      alert('Gagal menghapus folder. Jaringan bermasalah.');
    }
  };

  const filteredFolders = folders.filter(f => {
    const name = decryptedFolderNames[f.id] || '';
    return name.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const filteredFiles = files.filter(f => {
    const name = decryptedNames[f.id] || '';
    return name.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div style={{ marginTop: '8px' }}>
      
      {message && <p className="text-caption1-md" style={{ color: '#2563eb', textAlign: 'center' }}>{message}</p>}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <div style={{ display: 'flex', gap: '8px' }}>
          {currentFolderId && (
            <button onClick={handleGoBack} className="text-button" style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 12px', backgroundColor: '#6b7280', color: 'white', border: 'none', borderRadius: '16px', cursor: 'pointer' }}>
              <FaArrowLeft size={10} /> Kembali
            </button>
          )}
          
          <button onClick={handleCreateFolder} className="text-button" style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 12px', backgroundColor: '#3b82f6', color: 'white', border: 'none', borderRadius: '16px', cursor: 'pointer' }}>
            <FaFolderPlus size={12} /> Folder Baru
          </button>
        </div>

        <button 
          onClick={() => setViewMode(viewMode === 'list' ? 'grid' : 'list')}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#4b5563', padding: '8px' }}
        >
          {viewMode === 'list' ? <FaThLarge size={18} /> : <FaList size={18} />}
        </button>
      </div>

      {filteredFolders.length === 0 && filteredFiles.length === 0 ? (
        <p className="text-body2" style={{ color: '#6b7280', textAlign: 'center', padding: '40px 0', fontStyle: 'italic' }}>Folder ini kosong melompong bung.</p>
      ) : (
        <div style={
          viewMode === 'grid' 
            ? { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '16px' }
            : { display: 'flex', flexDirection: 'column', gap: '12px' }
        }>
          
        {filteredFolders.map(folder => (
            <div 
              key={folder.id} 
              onClick={() => handleEnterFolder(folder.id)}
              style={
                viewMode === 'grid'
                  ? { backgroundColor: 'white', padding: '16px 12px', borderRadius: '12px', border: '1px solid #e5e7eb', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', cursor: 'pointer', position: 'relative' }
                  : { backgroundColor: 'white', padding: '14px 16px', borderRadius: '12px', border: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', gap: '14px', cursor: 'pointer', position: 'relative' }
              }
            >
              <div style={viewMode === 'grid' ? { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', width: '100%' } : { display: 'flex', alignItems: 'center', gap: '14px', overflow: 'hidden', flex: 1 }}>
                <FaFolder size={viewMode === 'grid' ? 40 : 24} color="#facc15" style={{ flexShrink: 0 }} />
                <span className="text-button" style={{ color: '#374151', textAlign: viewMode === 'grid' ? 'center' : 'left', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', width: '100%' }}>
                  {decryptedFolderNames[folder.id] || (
                    <span className="text-caption1" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px', color: '#ef4444' }}>
                      <FaLock size={10} /> Lock...
                    </span>
                  )}
                </span>
              </div>

              {/* TOMBOL KEBAB MENU UNTUK FOLDER */}
              <div style={viewMode === 'grid' ? { position: 'absolute', top: '8px', right: '8px' } : { marginLeft: '12px', position: 'relative' }}>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveFolderMenuId(activeFolderMenuId === folder.id ? null : folder.id);
                  }}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', padding: '6px' }}
                >
                  <FaEllipsisV size={14} />
                </button>

                {/* DROPDOWN MENU FOLDER */}
                {activeFolderMenuId === folder.id && (
                  <div 
                    onClick={(e) => e.stopPropagation()} 
                    style={{ position: 'absolute', right: 0, top: '24px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', border: '1px solid #e5e7eb', zIndex: 60, display: 'flex', flexDirection: 'column', minWidth: '120px', overflow: 'hidden' }}
                  >
                    <button 
                      onClick={() => {
                        setActiveFolderMenuId(null);
                        handleDeleteFolder(folder.id);
                      }}
                      className="text-button"
                      style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left', color: '#ef4444', width: '100%' }}
                    >
                      <FaTrash size={12} color="#ef4444" /> Hapus
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {filteredFiles.map((file) => {
            const fileName = decryptedNames[file.id];
            const thumbnail = decryptedThumbnails[file.id];

            return (
              <div 
                key={file.id} 
                onClick={() => openPreview(file, decryptedNames[file.id])}
                style={
                  viewMode === 'grid'
                    ? { backgroundColor: 'white', padding: '12px', borderRadius: '12px', border: '1px solid #e5e7eb', display: 'flex', flexDirection: 'column', position: 'relative' }
                    : { backgroundColor: 'white', padding: '12px 16px', borderRadius: '12px', border: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'relative' }
                }
              >
                <div style={viewMode === 'grid' ? { display: 'flex', flexDirection: 'column', gap: '8px', width: '100%' } : { display: 'flex', alignItems: 'center', gap: '16px', overflow: 'hidden', flex: 1 }}>
                  <div style={
                    viewMode === 'grid'
                      ? { width: '100%', height: '100px', backgroundColor: '#e5e7eb', borderRadius: '8px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }
                      : { width: '48px', height: '48px', backgroundColor: '#e5e7eb', borderRadius: '8px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }
                  }>
                    {thumbnail ? (
                      <img src={thumbnail} alt="preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <FaFileAlt size={viewMode === 'grid' ? 32 : 20} color="#9ca3af" />
                    )}
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden', width: '100%' }}>
                    <span className="text-button" style={{ color: '#374151', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {fileName || (
                        <span className="text-caption1" style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#ef4444' }}>
                          <FaLock size={10} /> Mendekripsi...
                        </span>
                      )}
                    </span>
                    <span className="text-caption1" style={{ color: '#9ca3af', marginTop: '2px' }}>
                      {new Date(file.created_at).toLocaleDateString('id-ID')}
                    </span>
                  </div>
                </div>

                <div style={viewMode === 'grid' ? { position: 'absolute', top: '8px', right: '8px' } : { marginLeft: '12px', position: 'relative' }}>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveMenuId(activeMenuId === file.id ? null : file.id);
                    }}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', padding: '6px' }}
                  >
                    <FaEllipsisV size={14} />
                  </button>

                  {/* KEBAB MENU */}
                  {activeMenuId === file.id && (
                    <div
                      onClick={(e) => e.stopPropagation()}
                      style={{ position: 'absolute', right: 0, top: '24px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', border: '1px solid #e5e7eb', zIndex: 60, display: 'flex', flexDirection: 'column', minWidth: '120px', overflow: 'hidden' }}>
                      
                      <button 
                        onClick={() => handleDownloadFile(file.id, file.encrypted_name, file.original_name_encrypted)}
                        className="text-button"
                        style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left', color: '#374151', width: '100%' }}
                      >
                        <FaDownload size={12} color="#3b82f6" /> Download
                      </button>

                      <button 
                        onClick={() => handleToggleSave(file.id, file.is_saved)}
                        className="text-button"
                        style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left', color: '#374151', width: '100%', borderTop: '1px solid #f3f4f6' }}
                      >
                        {file.is_saved ? <FaBookmark size={12} color="#f59e0b" /> : <FaRegBookmark size={12} color="#6b7280" />} 
                        {file.is_saved ? 'Unsave' : 'Save'}
                      </button>
                      
                      <button 
                        onClick={() => handleDelete(file.id)}
                        className="text-button"
                        style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left', color: '#ef4444', width: '100%', borderTop: '1px solid #f3f4f6' }}
                      >
                        <FaTrash size={12} color="#ef4444" /> Hapus
                      </button>

                    </div>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
