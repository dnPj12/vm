import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { encryptFileForUpload, generateThumbnail, encryptText, decryptText, decryptFile } from '../utils/crypto';
import { FaFolder, FaFileAlt, FaLock, FaTrash, FaDownload, FaArrowLeft, FaFolderPlus } from 'react-icons/fa';

export default function Dashboard() {
  const [message, setMessage] = useState('');

  // State File & Folder
  const [files, setFiles] = useState([]);
  const [folders, setFolders] = useState([]);

  // State Navigasi Folder
  const [currentFolderId, setCurrentFolderId] = useState(null);
  const [parentHistory, setParentHistory] = useState([]);

  // State Dekripsi
  const [decryptedThumbnails, setDecryptedThumbnails] = useState({});
  const [decryptedNames, setDecryptedNames] = useState({});
  const [decryptedFolderNames, setDecryptedFolderNames] = useState({});

  // State Preview
  const [selectedFile, setSelectedFile] = useState(null);
  const [localPreview, setLocalPreview] = useState(null);
  const navigate = useNavigate();

  const token = localStorage.getItem('token');
  const vaultKey = sessionStorage.getItem('vaultKey');

  // --- FUNGSI FETCH UTAMA (FILE & FOLDER) ---
  const fetchVaultData = async () => {
    try {
      const resFolder = await fetch(`http://localhost:5000/api/folders?parentId=${currentFolderId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      const resFile = await fetch(`http://localhost:5000/api/files/list?folderId=${currentFolderId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (resFolder.ok && resFile.ok) {
        const folderData = await resFolder.json();
        const fileData = await resFile.json();

        setFolders(folderData);
        setFiles(fileData);

        const newDecryptedThumbnails = {};
        const newDecryptedNames = {};
        const newDecryptedFolderNames = {};

        if (vaultKey) {
          for (const folder of folderData) {
            if (folder.encrypted_name) {
              const realFolderName = await decryptText(folder.encrypted_name, vaultKey);
              if (realFolderName) newDecryptedFolderNames[folder.id] = realFolderName;
            }
          }

          for (const file of fileData) {
            if (file.original_name_encrypted) {
              const realName = await decryptText(file.original_name_encrypted, vaultKey);
              if (realName) newDecryptedNames[file.id] = realName;
            }
            if (file.encrypted_thumbnail) {
              const decryptedThumb = await decryptText(file.encrypted_thumbnail, vaultKey);
              if (decryptedThumb) newDecryptedThumbnails[file.id] = decryptedThumb;
            }
          }
        }

        setDecryptedFolderNames(newDecryptedFolderNames);
        setDecryptedThumbnails(newDecryptedThumbnails);
        setDecryptedNames(newDecryptedNames);
      }
    } catch (err) {
      console.error('Gagal memuat brankas:', err);
    }
  };

  useEffect(() => {
    if (!token || !vaultKey) {
      localStorage.removeItem('token');
      sessionStorage.removeItem('vaultKey');
      navigate('/');
    } else {
      fetchVaultData();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, vaultKey, navigate, currentFolderId]);

  // --- FUNGSI NAVIGASI FOLDER ---
  const handleCreateFolder = async () => {
    const folderName = prompt("Masukkan nama folder rahasia baru:");
    if (!folderName) return;

    const encryptedFolderName = await encryptText(folderName, vaultKey);

    try {
      const res = await fetch('http://localhost:5000/api/folders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          encryptedName: encryptedFolderName,
          parentId: currentFolderId
        })
      });

      if (res.ok) {
        fetchVaultData();
      } else {
        alert("Gagal membuat folder!");
      }
    } catch (err) {
      alert("Gagal membuat folder, jaringan error.");
    }
  };

  const handleEnterFolder = (folderId) => {
    setParentHistory([...parentHistory, currentFolderId]);
    setCurrentFolderId(folderId);
  };

  const handleGoBack = () => {
    const newHistory = [...parentHistory];
    const prevFolderId = newHistory.pop();
    setParentHistory(newHistory);
    setCurrentFolderId(prevFolderId);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    sessionStorage.removeItem('vaultKey');
    navigate('/');
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) {
      setSelectedFile(null);
      setLocalPreview(null);
      return;
    }

    setSelectedFile(file);
    setLocalPreview(null);

    const previewBase64 = await generateThumbnail(file);
    setLocalPreview(previewBase64);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    const fileInput = e.target.elements.fileInput.files[0];
    if (!fileInput) return alert('Pilih file dulu bung!');

    setMessage('Mengunci file otomatis dengan password akun lu...');

    try {
      const { encryptedBlob, encryptedName } = await encryptFileForUpload(fileInput, vaultKey);
      const thumbnailBase64 = await generateThumbnail(fileInput);
      const encryptedThumbnail = await encryptText(thumbnailBase64, vaultKey);
      const encryptedOriginalName = await encryptText(fileInput.name, vaultKey);

      const formData = new FormData();
      formData.append('file', encryptedBlob, encryptedName);
      formData.append('encryptedName', encryptedName);
      formData.append('originalNameEncrypted', encryptedOriginalName);
      if (encryptedThumbnail) formData.append('encryptedThumbnail', encryptedThumbnail);

      if (currentFolderId) {
        formData.append('folderId', currentFolderId);
      }

      const uploadRes = await fetch('http://localhost:5000/api/files/upload', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });

      if (uploadRes.ok) {
        setMessage(`File berhasil dienkripsi & diamankan ke GDrive!`);
        e.target.reset();
        setSelectedFile(null);
        setLocalPreview(null);
        fetchVaultData();
      } else {
        setMessage('Upload gagal diproses oleh server.');
      }
    } catch (err) {
      setMessage('Upload gagal. Cek koneksi.');
    }
  };

  const handleDownloadFile = async (fileId, encryptedName, originalNameEncrypted) => {
    setMessage('Menarik biner terenkripsi dari GDrive...');

    try {
      const res = await fetch(`http://localhost:5000/api/files/download/${fileId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });

      if (!res.ok) return alert('Akses ditolak oleh satpam server!');

      const encryptedBlob = await res.blob();
      setMessage('Biner diterima. Mengeksekusi pembongkaran matematika AES-GCM...');

      const decryptedBlob = await decryptFile(encryptedBlob, vaultKey);
      const originalName = await decryptText(originalNameEncrypted, vaultKey) || 'file_rahasia_tanpa_nama';

      const downloadUrl = window.URL.createObjectURL(decryptedBlob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', originalName);

      document.body.appendChild(link);
      link.click();

      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
      setMessage('File sukses didekripsi total dan berhasil diunduh bung!');

    } catch (err) {
      alert(err.message);
      setMessage('Proses dekripsi gagal. Biner menolak dibuka!');
    }
  };

  const handleDelete = async (fileId) => {
    if (!window.confirm('Yakin mau hapus file ini permanen? Data di GDrive juga bakal musnah bung.')) return;

    setMessage('Sedang menghapus file...');

    try {
      const res = await fetch(`http://localhost:5000/api/files/${fileId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (res.ok) {
        setMessage('File sukses dibumihanguskan!');
        fetchVaultData();
      } else {
        const data = await res.json();
        alert(`Gagal: ${data.message}`);
      }
    } catch (err) {
      alert('Terjadi kesalahan jaringan saat menghapus file.');
    }
  };

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f9fafb' }}>
      <nav style={{ backgroundColor: 'white', padding: '16px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
        <h2 style={{ margin: 0, color: '#111827' }}>niyStorage</h2>
        <button onClick={handleLogout} style={{ padding: '8px 16px', borderRadius: '6px', backgroundColor: '#ef4444', color: 'white', border: 'none', cursor: 'pointer', fontWeight: 'bold' }}>
          Logout
        </button>
      </nav>

      <main style={{ padding: '32px', maxWidth: '1200px', margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '32px' }}>

        {/* --- PANEL UPLOAD --- */}
        <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', height: 'fit-content' }}>
          <h3 style={{ marginTop: 0, color: '#374151', marginBottom: '20px' }}>Upload Otomatis</h3>
          <form onSubmit={handleUpload} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{ border: '2px dashed #d1d5db', padding: '20px', borderRadius: '8px', textAlign: 'center' }}>
              <input type="file" name="fileInput" onChange={handleFileChange} required style={{ width: '100%' }} />

              {selectedFile && (
                <div style={{ marginTop: '16px', display: 'flex', alignItems: 'center', gap: '12px', textAlign: 'left', backgroundColor: '#f9fafb', padding: '12px', borderRadius: '8px', border: '1px solid #e5e7eb' }}>
                  <div style={{ width: '50px', height: '50px', backgroundColor: '#e5e7eb', borderRadius: '6px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    {localPreview ? (
                      <img src={localPreview} alt="preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <FaFileAlt size={24} color="#9ca3af" />
                    )}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
                    <span style={{ fontSize: '14px', fontWeight: 'bold', color: '#374151', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {selectedFile.name}
                    </span>
                    <span style={{ fontSize: '12px', color: '#6b7280' }}>
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </span>
                  </div>
                </div>
              )}
            </div>
            <button type="submit" style={{ padding: '12px', borderRadius: '8px', backgroundColor: '#10b981', color: 'white', border: 'none', cursor: 'pointer', fontWeight: 'bold' }}>
              Enkripsi & Upload
            </button>
          </form>
          {message && <p style={{ color: '#2563eb', fontSize: '14px', marginTop: '16px' }}>{message}</p>}
        </div>

        {/* --- PANEL DAFTAR FOLDER & FILE --- */}
        <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '12px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
          <h3 style={{ marginTop: 0, color: '#374151', marginBottom: '20px' }}>
            Isi Brankas {currentFolderId ? 'Folder Ini' : 'Utama Lu'}
          </h3>

          {/* Tombol Kontrol Folder */}
          <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
            {currentFolderId && (
              <button onClick={handleGoBack} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', backgroundColor: '#6b7280', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
                <FaArrowLeft /> Kembali
              </button>
            )}
            <button onClick={handleCreateFolder} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', backgroundColor: '#3b82f6', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
              <FaFolderPlus /> Folder Baru
            </button>
          </div>

          {/* Render Daftar Folder Dulu */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px' }}>
            {folders.map(folder => (
              <div key={folder.id} onClick={() => handleEnterFolder(folder.id)} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', backgroundColor: '#f3f4f6', borderRadius: '8px', cursor: 'pointer', border: '1px solid #e5e7eb' }}>
                <FaFolder size={24} color="#facc15" /> 
                <span style={{ fontWeight: 'bold', color: '#374151' }}>
                  {decryptedFolderNames[folder.id] || (
                    <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#ef4444' }}>
                      <FaLock /> Mendekripsi...
                    </span>
                  )}
                </span>
              </div>
            ))}
          </div>

          {/* Render Daftar File */}
          {files.length === 0 && folders.length === 0 ? (
            <p style={{ color: '#6b7280', textAlign: 'center', padding: '20px 0' }}>Belum ada file atau folder terenkripsi bung.</p>
          ) : (
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {files.map((file) => (
                <li key={file.id} style={{ padding: '16px', borderBottom: '1px solid #f3f4f6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>

                    <div style={{ width: '50px', height: '50px', backgroundColor: '#e5e7eb', borderRadius: '8px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      {decryptedThumbnails[file.id] ? (
                        <img src={decryptedThumbnails[file.id]} alt="preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      ) : (
                        <FaFileAlt size={24} color="#9ca3af" />
                      )}
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      <span style={{ fontWeight: 'bold', color: '#374151', fontSize: '14px' }}>
                        {decryptedNames[file.id] || (
                          <span style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#ef4444' }}>
                            <FaLock /> Mendekripsi...
                          </span>
                        )}
                      </span>
                      <span style={{ fontSize: '12px', color: '#9ca3af', marginTop: '4px' }}>
                        {new Date(file.created_at).toLocaleString('id-ID')}
                      </span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button onClick={() => handleDownloadFile(file.id, file.encrypted_name, file.original_name_encrypted)} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', backgroundColor: '#3b82f6', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
                      <FaDownload /> Download
                    </button>
                    <button onClick={() => handleDelete(file.id)} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', backgroundColor: '#ef4444', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
                      <FaTrash /> Hapus
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

      </main>
    </div>
  );
}
