import { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { decryptText, decryptFile } from '../utils/crypto';
import { FaFileAlt, FaLock, FaDownload, FaTrash, FaEllipsisV, FaThLarge, FaList, FaBookmark, FaRegBookmark } from 'react-icons/fa';

export default function Home() {
  const { searchQuery, refreshKey, openPreview } = useOutletContext();

  const [files, setFiles] = useState([]);

  const [viewMode, setViewMode] = useState(() => {
    return localStorage.getItem('viewModePref') || 'list';
  });

  // 2. Simpan ke memori otomatis setiap kali tombol grid/list diklik
  useEffect(() => {
    localStorage.setItem('viewModePref', viewMode);
  }, [viewMode]);

  const [activeMenuId, setActiveMenuId] = useState(null);
  const [message, setMessage] = useState('');

  const [decryptedThumbnails, setDecryptedThumbnails] = useState({});
  const [decryptedNames, setDecryptedNames] = useState({});

  const token = localStorage.getItem('token');
  const vaultKey = sessionStorage.getItem('vaultKey');

  const fetchRecentFiles = async () => {
    try {
      const res = await fetch('/api/files/recent', {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (res.ok) {
        const data = await res.json();
        setFiles(data);

        const newDecryptedThumbnails = {};
        const newDecryptedNames = {};

        if (vaultKey) {
          for (const file of data) {
            try {
              if (file.original_name_encrypted) {
                const realName = await decryptText(file.original_name_encrypted, vaultKey);
                newDecryptedNames[file.id] = realName || 'File Tanpa Nama';
              }
            } catch (err) {
              newDecryptedNames[file.id] = '⚠️ Kunci Salah / Korup';
            }

            try {
              if (file.encrypted_thumbnail) {
                const decryptedThumb = await decryptText(file.encrypted_thumbnail, vaultKey);
                if (decryptedThumb) newDecryptedThumbnails[file.id] = decryptedThumb;
              }
            } catch (err) {
              console.warn(`Gagal dekripsi thumbnail file ID ${file.id}`);
            }
          }
        }
        
        setDecryptedThumbnails(newDecryptedThumbnails);
        setDecryptedNames(newDecryptedNames);
      }
    } catch (err) {
      console.error('Gagal memuat aktivitas terbaru:', err);
    }
  };

  useEffect(() => {
    fetchRecentFiles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey]);

  useEffect(() => {
    const handleOutsideClick = () => setActiveMenuId(null);
    window.addEventListener('click', handleOutsideClick);
    return () => window.removeEventListener('click', handleOutsideClick);
  }, []);

  const handleDownloadFile = async (fileId, encryptedName, originalNameEncrypted) => {
    setMessage('Menarik biner terenkripsi...');
    try {
      const res = await fetch(`/api/files/download/${fileId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      if (!res.ok) return alert('Akses ditolak server!');

      const encryptedBlob = await res.blob();
      const decryptedBlob = await decryptFile(encryptedBlob, vaultKey);
      const originalName = await decryptText(originalNameEncrypted, vaultKey) || 'file_rahasia';

      const downloadUrl = window.URL.createObjectURL(decryptedBlob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', originalName);
      document.body.appendChild(link);
      link.click();
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
      setMessage('');
    } catch (err) {
      alert('Gagal mendekripsi file biner. Kunci mungkin salah.');
      setMessage('');
    }
  };

  // --- FUNGSI TOGGLE SAVE / UNSAVE ---
  const handleToggleSave = async (fileId, isSaved) => {
    try {
      const method = isSaved ? 'DELETE' : 'POST';
      const res = await fetch(`/api/files/save/${fileId}`, {
        method,
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (res.ok) {
        fetchRecentFiles(); // Refresh UI biar ikon matanya berubah
      }
    } catch (err) {
      alert('Gagal mengubah status bookmark.');
    }
  };

  const handleDelete = async (fileId) => {
    if (!window.confirm('Hapus file ini permanen dari brankas bung?')) return;
    try {
      const res = await fetch(`/api/files/${fileId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        fetchRecentFiles();
      }
    } catch (err) {
      alert('Gagal menghapus file.');
    }
  };

  const filteredFiles = files.filter(file => {
    const fileName = decryptedNames[file.id] || '';
    return fileName.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div style={{ marginTop: '8px' }}>
      
      {message && <p className="text-caption1-md" style={{ color: '#2563eb', textAlign: 'center' }}>{message}</p>}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <h3 className="text-h2" style={{ margin: 0, color: '#1f2937' }}>recent activity</h3>
        <button 
          onClick={() => setViewMode(viewMode === 'list' ? 'grid' : 'list')}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#4b5563', padding: '8px' }}
        >
          {viewMode === 'list' ? <FaThLarge size={18} /> : <FaList size={18} />}
        </button>
      </div>

      {filteredFiles.length === 0 ? (
        <p className="text-body2" style={{ color: '#6b7280', textAlign: 'center', padding: '40px 0' }}>Belum ada aktivitas file bung.</p>
      ) : (
        <div style={
          viewMode === 'grid' 
            ? { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '16px' }
            : { display: 'flex', flexDirection: 'column', gap: '12px' }
        }>
          {filteredFiles.map((file) => {
            const fileName = decryptedNames[file.id];
            const thumbnail = decryptedThumbnails[file.id];

            return (
              <div 
                key={file.id} 
                onClick={() => openPreview(file, decryptedNames[file.id])}
                style={
                  viewMode === 'grid'
                    ? { backgroundColor: 'white', padding: '12px', borderRadius: '12px', border: '1px solid #e5e7eb', display: 'flex', flexDirection: 'column', position: 'relative' }
                    : { backgroundColor: 'white', padding: '12px 16px', borderRadius: '12px', border: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'relative' }
                }
              >
                <div style={viewMode === 'grid' ? { display: 'flex', flexDirection: 'column', gap: '8px', width: '100%' } : { display: 'flex', alignItems: 'center', gap: '16px', overflow: 'hidden', flex: 1 }}>
                  <div style={
                    viewMode === 'grid'
                      ? { width: '100%', height: '100px', backgroundColor: '#e5e7eb', borderRadius: '8px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }
                      : { width: '48px', height: '48px', backgroundColor: '#e5e7eb', borderRadius: '8px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }
                  }>
                    {thumbnail ? (
                      <img src={thumbnail} alt="preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    ) : (
                      <FaFileAlt size={viewMode === 'grid' ? 32 : 20} color="#9ca3af" />
                    )}
                  </div>

                  <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden', width: '100%' }}>
                    <span className="text-button" style={{ color: '#374151', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {fileName || (
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#ef4444' }}>
                          <FaLock size={10} /> Mendekripsi...
                        </span>
                      )}
                    </span>
                    <span className="text-caption1" style={{ color: '#9ca3af', marginTop: '2px' }}>
                      You uploaded • {new Date(file.created_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>

                <div style={viewMode === 'grid' ? { position: 'absolute', top: '8px', right: '8px' } : { marginLeft: '12px', position: 'relative' }}>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveMenuId(activeMenuId === file.id ? null : file.id);
                    }}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', padding: '6px' }}
                  >
                    <FaEllipsisV size={14} />
                  </button>

                  {/* KEBAB MENU */}
                  {activeMenuId === file.id && (

                    <div
                      onClick={(e) => e.stopPropagation()}
                      style={{ position: 'absolute', right: 0, top: '24px', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', border: '1px solid #e5e7eb', zIndex: 60, display: 'flex', flexDirection: 'column', minWidth: '120px', overflow: 'hidden' }}>
                      
                      {/* 1. TOMBOL DOWNLOAD */}
                      <button 
                        onClick={() => handleDownloadFile(file.id, file.encrypted_name, file.original_name_encrypted)}
                        className="text-button"
                        style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left', color: '#374151', width: '100%' }}
                      >
                        <FaDownload size={12} color="#3b82f6" /> Download
                      </button>

                      {/* 2. TOMBOL SAVE / UNSAVE */}
                      <button 
                        onClick={() => handleToggleSave(file.id, file.is_saved)}
                        className="text-button"
                        style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left', color: '#374151', width: '100%', borderTop: '1px solid #f3f4f6' }}
                      >
                        {file.is_saved ? <FaBookmark size={12} color="#f59e0b" /> : <FaRegBookmark size={12} color="#6b7280" />} 
                        {file.is_saved ? 'Unsave' : 'Save'}
                      </button>
                      
                      {/* 3. TOMBOL HAPUS */}
                      <button 
                        onClick={() => handleDelete(file.id)}
                        className="text-button"
                        style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', border: 'none', background: 'none', cursor: 'pointer', textAlign: 'left', color: '#ef4444', width: '100%', borderTop: '1px solid #f3f4f6' }}
                      >
                        <FaTrash size={12} color="#ef4444" /> Hapus
                      </button>

                    </div>
                  )}
                </div>

              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
