import { useNavigate } from 'react-router-dom';
import { FaShieldAlt, FaKey, FaLock, FaServer, FaArrowLeft } from 'react-icons/fa';

export default function About() {
  const navigate = useNavigate();
  const currentYear = new Date().getFullYear();

  return (
    <div style={{ padding: '24px', maxWidth: '500px', margin: '0 auto', boxSizing: 'border-box', paddingBottom: '100px' }}>
      
      {/* Tombol Kembali (Navigasi Header) */}
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '24px' }}>
        <button 
          onClick={() => navigate(-1)} // Memanfaatkan history browser untuk balik ke halaman sebelumnya (Settings)
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '50%', backgroundColor: '#f3f4f6', outline: 'none' }}
        >
          <FaArrowLeft size={16} color="#4b5563" />
        </button>
        {/* IMPLEMENTASI: text-body2-md */}
        <span className="text-body2-md" style={{ color: '#1f2937', marginLeft: '12px' }}>Kembali</span>
      </div>

      {/* Header / Logo Section */}
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <div style={{ width: '80px', height: '80px', backgroundColor: '#eff6ff', borderRadius: '24px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto', marginBottom: '16px', boxShadow: '0 4px 12px rgba(59, 130, 246, 0.15)' }}>
          <FaShieldAlt size={40} color="#3b82f6" />
        </div>
        {/* IMPLEMENTASI: text-h2 */}
        <h3 className="text-h2" style={{ color: '#1f2937', marginBottom: '4px', margin: 0 }}>niyStorage</h3>
        {/* IMPLEMENTASI: text-caption1 */}
        <span className="text-caption1" style={{ color: '#9ca3af', letterSpacing: '1px' }}>VERSION 1.0.0</span>
      </div>

      {/* Deskripsi Singkat */}
      {/* IMPLEMENTASI: text-body2 */}
      <p className="text-body2" style={{ color: '#4b5563', textAlign: 'center', lineHeight: '1.6', marginBottom: '32px', margin: 0 }}>
        Brankas digital privat berbasis <span style={{ fontWeight: '600', color: '#10b981' }}>Zero-Knowledge Architecture</span>. 
        Tempat teraman untuk mengunci berkas sensitif lu langsung dari genggaman tanpa kompromi privasi.
      </p>

      {/* Pilar Keamanan (Fitur Utama) */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', marginBottom: '40px' }}>
        
        {/* Pilar 1 */}
        <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
          <div style={{ padding: '10px', backgroundColor: '#f3f4f6', borderRadius: '12px', color: '#374151', flexShrink: 0, display: 'flex' }}>
            <FaKey size={16} />
          </div>
          <div>
            {/* IMPLEMENTASI: text-button */}
            <span className="text-button" style={{ color: '#1f2937', display: 'block', marginBottom: '4px' }}>Enkripsi Sisi Klien</span>
            {/* IMPLEMENTASI: text-caption1 */}
            <span className="text-caption1" style={{ color: '#6b7280', lineHeight: '1.4', display: 'block' }}>
              Semua file dienkripsi murni di dalam RAM perangkat lu menggunakan Web Crypto API sebelum dikirim ke awan.
            </span>
          </div>
        </div>

        {/* Pilar 2 */}
        <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
          <div style={{ padding: '10px', backgroundColor: '#f3f4f6', borderRadius: '12px', color: '#374151', flexShrink: 0, display: 'flex' }}>
            <FaLock size={16} />
          </div>
          <div>
            {/* IMPLEMENTASI: text-button */}
            <span className="text-button" style={{ color: '#1f2937', display: 'block', marginBottom: '4px' }}>Kunci Rahasia Terisolasi</span>
            {/* IMPLEMENTASI: text-caption1 */}
            <span className="text-caption1" style={{ color: '#6b7280', lineHeight: '1.4', display: 'block' }}>
              Kunci brankas (*vaultKey*) hanya hidup di memori sesi browser lu dan tidak pernah menyentuh harddisk server mana pun.
            </span>
          </div>
        </div>

        {/* Pilar 3 */}
        <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
          <div style={{ padding: '10px', backgroundColor: '#f3f4f6', borderRadius: '12px', color: '#374151', flexShrink: 0, display: 'flex' }}>
            <FaServer size={16} />
          </div>
          <div>
            {/* IMPLEMENTASI: text-button */}
            <span className="text-button" style={{ color: '#1f2937', display: 'block', marginBottom: '4px' }}>Penyimpanan Terdesentralisasi</span>
            {/* IMPLEMENTASI: text-caption1 */}
            <span className="text-caption1" style={{ color: '#6b7280', lineHeight: '1.4', display: 'block' }}>
              Mengandalkan database terstruktur lokal yang menjembatani penyimpanan awan secara anonim dan terfragmentasi.
            </span>
          </div>
        </div>

      </div>

      {/* Footer / Copyright Box */}
      <div style={{ borderTop: '1px solid #e5e7eb', paddingTop: '20px', textAlign: 'center' }}>
        {/* IMPLEMENTASI: text-caption1 */}
        <p className="text-caption1" style={{ color: '#9ca3af', margin: 0 }}>
          © {currentYear} niyStorage Project. All rights reserved.
        </p>
        {/* IMPLEMENTASI: text-caption1 */}
        <p className="text-caption1" style={{ color: '#3b82f6', marginTop: '6px', fontWeight: '500', cursor: 'pointer', margin: '6px 0 0 0' }}>
          Syarat & Ketentuan Penggunaan
        </p>
      </div>

    </div>
  );
}
