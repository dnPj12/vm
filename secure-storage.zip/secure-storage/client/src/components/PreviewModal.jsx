import { useState, useEffect } from 'react';
import { FaTimes, FaSpinner, FaFileAlt, FaDownload } from 'react-icons/fa';
import { decryptFile } from '../utils/crypto';

export default function PreviewModal({ file, fileName, onClose }) {
  const [isLoading, setIsLoading] = useState(true);
  const [fileUrl, setFileUrl] = useState(null);
  const [textContent, setTextContent] = useState('');
  const [fileType, setFileType] = useState('unsupported');
  const [error, setError] = useState('');

  const token = localStorage.getItem('token');
  const vaultKey = sessionStorage.getItem('vaultKey');

useEffect(() => {
    if (!file || !fileName) return;

    const controller = new AbortController();
    const { signal } = controller;
    let objectUrl = null;

    const fetchAndDecrypt = async () => {
      setIsLoading(true);
      setError('');

      const ext = fileName.split('.').pop().toLowerCase();
      let type = 'unsupported';
      
      if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext)) type = 'image';
      else if (['mp4', 'webm', 'ogg'].includes(ext)) type = 'video';
      else if (['mp3', 'wav'].includes(ext)) type = 'audio';
      else if (ext === 'pdf') type = 'pdf';
      else if (['txt', 'json', 'md', 'js', 'css', 'html'].includes(ext)) type = 'text';

      setFileType(type);

      if (type === 'unsupported') {
        if (!signal.aborted) setIsLoading(false);
        return;
      }

      try {
        const res = await fetch(`/api/files/download/${file.id}`, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}` },
          signal
        });

        if (!res.ok) throw new Error('Akses ditolak server');

        const encryptedBlob = await res.blob();
        const decryptedBlob = await decryptFile(encryptedBlob, vaultKey);

        // --- SUNTIKKAN MIME TYPE DI SINI BUNG ---
        let mimeType = 'application/octet-stream';
        if (type === 'pdf') mimeType = 'application/pdf';
        else if (type === 'image') mimeType = `image/${ext === 'jpg' ? 'jpeg' : ext}`;
        else if (type === 'video') mimeType = `video/${ext}`;
        else if (type === 'audio') mimeType = `audio/${ext}`;

        // Bikin Blob baru yang udah punya identitas jelas
        const properBlob = new Blob([decryptedBlob], { type: mimeType });
        // ----------------------------------------

        if (signal.aborted) return; 

        if (type === 'text') {
          const text = await properBlob.text(); // Pakai properBlob
          setTextContent(text);
        } else {
          objectUrl = URL.createObjectURL(properBlob); // Pakai properBlob
          setFileUrl(objectUrl);
        }
      } catch (err) {
        // SATPAM 2: Kalau error-nya karena dibatalin, diamkan saja
        if (signal.aborted) return; 
        
        console.error('Preview error:', err);
        setError('Gagal membuka file. Kunci brankas mungkin salah atau jaringan bermasalah.');
      } finally {
        // SATPAM 3: Jangan matikan loading kalau ini adalah request yang dibatalkan
        if (!signal.aborted) {
          setIsLoading(false);
        }
      }
    };

    fetchAndDecrypt();

    return () => {
      controller.abort();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [file, fileName, token, vaultKey]);

  if (!file) return null;

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.9)', zIndex: 9999, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: 'white' }}>
      
      {/* Header Pop-up */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' }}>
        <span className="text-body2-md" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '80%' }}>
          {fileName}
        </span>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'white', cursor: 'pointer', padding: '8px' }}>
          <FaTimes size={24} />
        </button>
      </div>

      {/* Area Konten Preview */}
      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '60px 16px 24px 16px', boxSizing: 'border-box' }}>
        
        {isLoading ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' }}>
            <FaSpinner className="spin-animation" size={32} color="#3b82f6" style={{ animation: 'spin 1s linear infinite' }} />
            <span className="text-caption1">Loading...</span>
          </div>
        ) : error ? (
          <div className="text-body2" style={{ color: '#ef4444', textAlign: 'center' }}>{error}</div>
        ) : fileType === 'unsupported' ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px', textAlign: 'center' }}>
            <FaFileAlt size={48} color="#9ca3af" />
            <p className="text-body2">Format file ini tidak bisa di-preview langsung oleh browser.</p>
            <p className="text-caption1" style={{ color: '#9ca3af' }}>Gunakan tombol Download pada menu untuk membukanya.</p>
          </div>
        ) : (
          /* Render Media Sesuai Format */
          <>
            {fileType === 'image' && <img src={fileUrl} alt="preview" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />}
            
            {fileType === 'video' && <video src={fileUrl} controls autoPlay style={{ maxWidth: '100%', maxHeight: '100%' }} />}
            
            {fileType === 'audio' && <audio src={fileUrl} controls autoPlay style={{ width: '100%', maxWidth: '300px' }} />}
            
            {fileType === 'pdf' && (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px', textAlign: 'center' }}>
                <FaFileAlt size={64} color="#ef4444" />
                <p className="text-body2">Browser HP tidak mendukung preview PDF di dalam kotak.</p>
                <a 
                  href={fileUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  style={{ backgroundColor: '#ef4444', color: 'white', padding: '12px 24px', borderRadius: '8px', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 'bold' }}
                >
                  Buka di Penampil PDF
                </a>
              </div>
            )}
            
            {fileType === 'text' && (
              <div style={{ width: '100%', height: '100%', overflow: 'auto', backgroundColor: '#1f2937', padding: '16px', borderRadius: '8px', textAlign: 'left' }}>
                <pre className="text-caption1" style={{ whiteSpace: 'pre-wrap', wordWrap: 'break-word', fontFamily: 'monospace' }}>
                  {textContent}
                </pre>
              </div>
            )}
          </>
        )}
      </div>

      {/* Tambahan CSS kecil untuk animasi loading */}
      <style>{`
        @keyframes spin { 100% { transform: rotate(360deg); } }
      `}</style>

    </div>
  );
}
