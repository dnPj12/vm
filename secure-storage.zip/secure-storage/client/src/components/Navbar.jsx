import { useNavigate, useLocation } from 'react-router-dom';
import { FaHome, FaFolder, FaShareAlt, FaCog, FaBookmark } from 'react-icons/fa';
import { AiFillHome } from "react-icons/ai";

export default function Navbar({ setCurrentFolderId }) {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { path: '/home', label: 'Home', icon: <AiFillHome size={22} /> },
    { path: '/files', label: 'Files', icon: <FaFolder size={22} /> },
    { path: '/saved', label: 'Saved', icon: <FaBookmark size={22} /> },
    { path: '/settings', label: 'Settings', icon: <FaCog size={22} /> },
  ];

  const handleNavigation = (path) => {
    if (path !== '/files') {
      setCurrentFolderId(null);
    }
    navigate(path);
  };

  return (
    <nav style={{ position: 'fixed', bottom: 0, left: 0, right: 0, height: '66px', backgroundColor: 'white', display: 'flex', justifyContent: 'space-around', alignItems: 'center', boxShadow: '0 -2px 10px rgba(0,0,0,0.05)', borderTop: '1px solid #e5e7eb', zIndex: 50 }}>
      {menuItems.map((item) => {
        const isActive = location.pathname === item.path;
        return (
          <div 
            key={item.path} 
            onClick={() => handleNavigation(item.path)} 
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: isActive ? '#2563eb' : '#6b7280', flex: 1, height: '100%' }}
          >
            {item.icon}
            
            {/* IMPLEMENTASI: text-caption2-md (10px medium) */}
            <span className="text-caption2-md" style={{ marginTop: '4px', fontWeight: isActive ? '600' : '500' }}>
              {item.label}
            </span>
          </div>
        );
      })}
    </nav>
  );
}
