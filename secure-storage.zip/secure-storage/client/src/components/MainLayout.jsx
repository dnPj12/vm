import { useState } from 'react';
import { Outlet, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useSwipeable } from 'react-swipeable';
import Header from './Header';
import Navbar from './Navbar';
import UploadModal from './UploadModal';
import PreviewModal from './PreviewModal'; // 1. Import komponen modal baru

export default function MainLayout() {
  const token = localStorage.getItem('token');
  const vaultKey = sessionStorage.getItem('vaultKey');
  const location = useLocation();
  const navigate = useNavigate();

  if (!token || !vaultKey) {
    return <Navigate to="/" replace />;
  }

  const [searchQuery, setSearchQuery] = useState('');
  const [currentFolderId, setCurrentFolderId] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0); 

  // 2. State untuk mengontrol Preview File
  const [previewData, setPreviewData] = useState(null);

  const triggerRefresh = () => setRefreshKey(prev => prev + 1);

  // 3. Fungsi yang akan dipanggil oleh halaman anak
  const openPreview = (file, fileName) => {
    setPreviewData({ file, fileName });
  };

  const isSettingsPage = location.pathname === '/settings';

  const routes = ['/home', '/files', '/saved', '/settings'];

  const handlers = useSwipeable({
    onSwipedLeft: (eventData) => {
      if (eventData.absY > eventData.absX / 2) return; 

      const currentIndex = routes.indexOf(location.pathname);
      if (currentIndex !== -1 && currentIndex < routes.length - 1) {
        if (location.pathname !== '/files') setCurrentFolderId(null);
        navigate(routes[currentIndex + 1]);
      }
    },
    onSwipedRight: (eventData) => {
      if (eventData.absY > eventData.absX / 2) return;

      const currentIndex = routes.indexOf(location.pathname);
      if (currentIndex > 0) {
        if (location.pathname !== '/files') setCurrentFolderId(null);
        navigate(routes[currentIndex - 1]);
      }
    },
    delta: 60, 
    trackMouse: false
  });

  return (
    <div {...handlers} style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', position: 'relative', backgroundColor: '#f9fafb', overflowX: 'hidden' }}>
      
      {!isSettingsPage && <Header setSearchQuery={setSearchQuery} />}
      
      <main style={{ flex: 1, padding: isSettingsPage ? '24px 16px 90px 16px' : '0 16px 90px 16px', boxSizing: 'border-box' }}>
        {/* 4. Oper openPreview ke dalam context Outlet */}
        <Outlet context={{ searchQuery, currentFolderId, setCurrentFolderId, refreshKey, triggerRefresh, openPreview }} />
      </main>
      
      <UploadModal currentFolderId={currentFolderId} triggerRefresh={triggerRefresh} />
      
      <Navbar setCurrentFolderId={setCurrentFolderId} />

      {/* 5. Pasang PreviewModal di layer paling atas */}
      {previewData && (
        <PreviewModal 
          file={previewData.file} 
          fileName={previewData.fileName} 
          onClose={() => setPreviewData(null)} 
        />
      )}
    </div>
  );
}
