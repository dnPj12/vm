import { FaSearch } from 'react-icons/fa';

export default function Header({ setSearchQuery }) {
  return (
    <div style={{ padding: '16px', backgroundColor: '#f9fafb', position: 'sticky', top: 0, zIndex: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', backgroundColor: '#e5e7eb', padding: '10px 16px', borderRadius: '24px' }}>
        <FaSearch color="#6b7280" style={{ marginRight: '10px', flexShrink: 0 }} />
        <input
          type="text"
          placeholder="search folder or file"
          onChange={(e) => setSearchQuery(e.target.value)}
          /* IMPLEMENTASI: text-body2 */
          className="text-body2"
          style={{ border: 'none', background: 'transparent', outline: 'none', width: '100%', color: '#1f2937' }}
        />
      </div>
    </div>
  );
}
