import { useState, useRef } from 'react';
import { FaPlus, FaFileAlt, FaCloudUploadAlt, FaSpinner } from 'react-icons/fa';
import { encryptFileForUpload, generateThumbnail, encryptText } from '../utils/crypto';

export default function UploadModal({ currentFolderId, triggerRefresh }) {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [localPreview, setLocalPreview] = useState(null);
  
  // State baru untuk Drag & Drop
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const token = localStorage.getItem('token');
  const vaultKey = sessionStorage.getItem('vaultKey');
  const fileInputRef = useRef(null);

  // --- 1. HANDLE FILE MANUAL (Bawaan lu) ---
  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) {
      setSelectedFile(null);
      setLocalPreview(null);
      return;
    }
    setSelectedFile(file);
    const previewBase64 = await generateThumbnail(file);
    setLocalPreview(previewBase64);
  };

  // --- 2. EKSEKUTOR UPLOAD TUNGGAL (Dipakai manual & drop) ---
  const executeSingleFileUpload = async (file, targetFolderId) => {
    setMessage(`Mengenkripsi: ${file.name}...`);
    
    // Pakai fungsi kripto bawaan lu!
    const { encryptedBlob, encryptedName } = await encryptFileForUpload(file, vaultKey);
    const thumbnailBase64 = await generateThumbnail(file);
    const encryptedThumbnail = await encryptText(thumbnailBase64, vaultKey);
    const encryptedOriginalName = await encryptText(file.name, vaultKey);

    setMessage(`Mengunggah: ${file.name}...`);

    const formData = new FormData();
    formData.append('file', encryptedBlob, encryptedName);
    formData.append('encryptedName', encryptedName);
    formData.append('originalNameEncrypted', encryptedOriginalName);
    if (encryptedThumbnail) formData.append('encryptedThumbnail', encryptedThumbnail);
    if (targetFolderId) formData.append('folderId', targetFolderId);

    const res = await fetch('/api/files/upload', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` },
      body: formData
    });

    if (!res.ok) throw new Error(`Upload gagal: ${file.name}`);
  };

// --- FUNGSI 3: PEMBUAT FOLDER ---
  const createFolderInBackend = async (folderName, parentId) => {
    setMessage(`Membuat folder: ${folderName}...`);
    const encryptedName = await encryptText(folderName, vaultKey);
    
    const res = await fetch('/api/folders', {
      method: 'POST',
      headers: { 
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ encryptedName, parentId })
    });

    if (!res.ok) throw new Error(`Gagal bikin folder ${folderName}`);
    const data = await res.json();
    
    // --- CCTV FRONTEND ---
    console.log(`[CCTV FRONTEND] Node.js ngasih ID Folder:`, data.folderId);
    
    return data.folderId; 
  };

  // --- FUNGSI 4: REKURSIF ---
  const uploadEntry = async (entry, parentId) => {
    // --- CCTV FRONTEND ---
    console.log(`[CCTV DETEKTOR] Membaca: ${entry.name} | Apakah ini Folder? ${entry.isDirectory}`);

    if (entry.isFile) {
      const file = await new Promise((resolve) => entry.file(resolve));
      await executeSingleFileUpload(file, parentId);
    } else if (entry.isDirectory) {
      const newFolderId = await createFolderInBackend(entry.name, parentId);
      const dirReader = entry.createReader();

      const readAllEntries = async () => {
        let all = [];
        let entries = await new Promise((resolve) => dirReader.readEntries(resolve));
        while (entries.length > 0) {
          all = all.concat(entries);
          entries = await new Promise((resolve) => dirReader.readEntries(resolve));
        }
        return all;
      };

      const allEntries = await readAllEntries();
      for (const subEntry of allEntries) {
        await uploadEntry(subEntry, newFolderId); // newFolderId disuntikkan ke anak-anaknya
      }
    }
  };


  // --- 5. HANDLER DROP (SUDAH ANTI GARBAGE COLLECTION) ---
  const handleDrop = async (e) => {
    e.preventDefault();
    setIsDragging(false);
    
    const items = e.dataTransfer.items;
    if (!items || items.length === 0) return;

    // 1. KUMPULKAN DATA SECARA INSTAN! (Jangan pakai await di sini)
    // Ini menyelamatkan antrean sebelum dihancurkan oleh browser
    const rootEntries = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.webkitGetAsEntry) {
        const entry = item.webkitGetAsEntry();
        if (entry) rootEntries.push(entry);
      }
    }

    setIsUploading(true);
    setMessage('Memulai pemrosesan antrean...');
    setSelectedFile(null); 
    setLocalPreview(null);

    try {
      // 2. Sekarang baru kita proses secara berurutan dengan aman
      for (const entry of rootEntries) {
        await uploadEntry(entry, currentFolderId);
      }
      setMessage('Semua file & folder berhasil diamankan!');
      triggerRefresh();
      setTimeout(() => { setIsOpen(false); setMessage(''); }, 1500);
    } catch (err) {
      console.error(err);
      setMessage('Upload drop gagal. Cek log.');
    } finally {
      setIsUploading(false);
    }
  };


  // --- 6. HANDLER SUBMIT MANUAL ---
  const handleManualUpload = async (e) => {
    e.preventDefault();
    if (!selectedFile) return alert('Pilih file dulu bung!');

    setIsUploading(true);
    try {
      await executeSingleFileUpload(selectedFile, currentFolderId);
      setMessage('File berhasil dienkripsi total bung!');
      setSelectedFile(null);
      setLocalPreview(null);
      triggerRefresh();
      setTimeout(() => { setIsOpen(false); setMessage(''); }, 1000);
    } catch (err) {
      setMessage('Upload manual gagal.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <>
      {/* Floating Action Button (Bawaan lu) */}
      <button onClick={() => setIsOpen(true)} style={{ position: 'fixed', bottom: '86px', right: '24px', width: '56px', height: '56px', borderRadius: '28px', backgroundColor: '#e5e7eb', border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 12px rgba(0,0,0,0.2)', cursor: 'pointer', zIndex: 40, outline: 'none' }}>
        <FaPlus size={22} color="#1f2937" />
      </button>

      {/* Modal Bottom Sheet */}
      {isOpen && (
        <div style={{ position: 'fixed', top: 0, bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'flex-end', zIndex: 100 }} onClick={() => !isUploading && setIsOpen(false)}>
          <div style={{ backgroundColor: 'white', width: '100%', borderTopLeftRadius: '24px', borderTopRightRadius: '24px', padding: '24px', boxSizing: 'border-box' }} onClick={(e) => e.stopPropagation()}>

            <h3 className="text-h2" style={{ color: '#374151', marginBottom: '20px', textAlign: 'center' }}>Upload ke Brankas</h3>

            <form onSubmit={handleManualUpload} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              
              {/* AREA DROPZONE (Gabungan desain lu + Drop) */}
              <div 
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={(e) => { e.preventDefault(); setIsDragging(false); }}
                onDrop={handleDrop}
                style={{ 
                  border: `2px dashed ${isDragging ? '#3b82f6' : '#d1d5db'}`, 
                  padding: '24px', 
                  borderRadius: '12px', 
                  textAlign: 'center', 
                  backgroundColor: isDragging ? '#eff6ff' : '#f9fafb',
                  transition: 'all 0.2s',
                  position: 'relative'
                }}
              >
                {/* Kalau lagi upload bulk dari Drop, munculin spinner */}
                {isUploading && !selectedFile ? (
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px', padding: '20px 0' }}>
                    <FaSpinner className="spin-animation" size={32} color="#10b981" style={{ animation: 'spin 1s linear infinite' }} />
                    <span className="text-caption1-md" style={{ color: '#374151' }}>Memproses antrean...</span>
                  </div>
                ) : (
                  <>
                    <FaCloudUploadAlt size={40} color={isDragging ? '#3b82f6' : '#9ca3af'} style={{ marginBottom: '12px' }} />
                    <p className="text-caption1-md" style={{ color: '#6b7280', marginBottom: '12px' }}>
                      Drag & Drop Folder / File ke sini
                    </p>
                    
                    {/* Input manual bawaan lu */}
                    <input 
                      type="file" 
                      onChange={handleFileChange} 
                      ref={fileInputRef}
                      disabled={isUploading}
                      style={{ width: '100%', fontSize: '12px' }} 
                    />

                    {/* Preview file tunggal bawaan lu */}
                    {selectedFile && (
                      <div style={{ marginTop: '16px', display: 'flex', alignItems: 'center', gap: '12px', textAlign: 'left', backgroundColor: 'white', padding: '12px', borderRadius: '8px', border: '1px solid #e5e7eb' }}>
                        <div style={{ width: '50px', height: '50px', backgroundColor: '#e5e7eb', borderRadius: '6px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          {localPreview ? (
                            <img src={localPreview} alt="preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                          ) : (
                            <FaFileAlt size={24} color="#9ca3af" />
                          )}
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
                          <span className="text-button" style={{ color: '#374151', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{selectedFile.name}</span>
                          <span className="text-caption1" style={{ color: '#6b7280', marginTop: '2px' }}>{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</span>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>

              {/* Tombol submit manual (Hanya bisa diklik kalau milih file manual) */}
              <button 
                type="submit" 
                disabled={isUploading || !selectedFile}
                className="text-button" 
                style={{ padding: '14px', borderRadius: '8px', backgroundColor: (isUploading || !selectedFile) ? '#d1d5db' : '#10b981', color: 'white', border: 'none', cursor: (isUploading || !selectedFile) ? 'not-allowed' : 'pointer', fontWeight: '500' }}
              >
                {isUploading ? 'Memproses...' : 'Enkripsi & Upload Manual'}
              </button>
            </form>

            {message && <p className="text-caption1-md" style={{ color: '#2563eb', marginTop: '16px', textAlign: 'center' }}>{message}</p>}
          </div>
        </div>
      )}

      {/* Animasi spinner */}
      <style>{`
        @keyframes spin { 100% { transform: rotate(360deg); } }
      `}</style>
    </>
  );
}
