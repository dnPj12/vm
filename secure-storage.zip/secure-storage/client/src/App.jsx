import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Auth from './pages/Auth';
import MainLayout from './components/MainLayout';

import Home from './pages/Home'; 
import Files from './pages/Files';
import Saved from './pages/Saved'; // <-- Impor halaman Saved baru lu bung
import Settings from './pages/Settings';
import About from './pages/About';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Auth />} />

        <Route element={<MainLayout />}>
          <Route path="/home" element={<Home />} />
          <Route path="/files" element={<Files />} />
          
          {/* UBAH RUTE /SHARED JADI /SAVED DI SINI */}
          <Route path="/saved" element={<Saved />} /> 

          <Route path="/settings" element={<Settings />} /> 
          
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />

        <Route path="/about" element={<About />} />
      </Routes>
    </BrowserRouter>
  );
}
