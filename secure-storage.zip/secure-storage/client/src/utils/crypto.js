// client/src/utils/crypto.js
// client/src/utils/crypto.js
import * as pdfjsLib from 'pdfjs-dist';
// Tarik worker langsung dari lokal pakai parameter ?url bawaan Vite
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

// 1. Ekstraksi DNA (Kunci Kriptografi dari Password)
export async function deriveKey(password, salt) {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveBits", "deriveKey"]
  );
  return window.crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt,
      iterations: 100000,
      hash: "SHA-256",
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    true,
    ["encrypt", "decrypt"]
  );
}

// 2. Enkripsi File Utama untuk di-upload ke GDrive
export async function encryptFileForUpload(file, password) {
  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(password, salt);

  const fileBuffer = await file.arrayBuffer();
  const encryptedContent = await window.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv },
    key,
    fileBuffer
  );

  // Gabungkan Salt, IV, dan File yang sudah dienkripsi menjadi satu file biner
  const combinedBuffer = new Uint8Array(16 + 12 + encryptedContent.byteLength);
  combinedBuffer.set(salt, 0);
  combinedBuffer.set(iv, 16);
  combinedBuffer.set(new Uint8Array(encryptedContent), 16 + 12);

  const encryptedBlob = new Blob([combinedBuffer], { type: 'application/octet-stream' });
  
  // Buat nama acak untuk GDrive
  const randomString = crypto.randomUUID().replace(/-/g, '');
  const encryptedName = `${randomString}.bin`;

  return { encryptedBlob, encryptedName };
}

// 3. Buat Thumbnail (Support Gambar & Video)
export function generateThumbnail(file) {
  return new Promise((resolve) => {
    
    // --- CABANG 1: KALAU FILE ADALAH GAMBAR ---
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 100;
          const scaleSize = MAX_WIDTH / img.width;
          canvas.width = MAX_WIDTH;
          canvas.height = img.height * scaleSize;
          
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', 0.6));
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
      return; // Stop di sini kalau gambar
    }

    // --- CABANG 2: KALAU FILE ADALAH VIDEO ---
    if (file.type.startsWith('video/')) {
      const video = document.createElement('video');
      video.src = URL.createObjectURL(file);
      video.crossOrigin = 'anonymous'; 
      video.muted = true; // Wajib di-mute agar browser mengizinkan proses di background

      // Lompat ke detik ke-1 agar tidak mendapatkan frame awal yang hitam
      video.currentTime = 1;

      // Event ini terpicu saat video selesai melompat ke detik 1
      video.onseeked = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 100;
        const scaleSize = MAX_WIDTH / video.videoWidth;
        canvas.width = MAX_WIDTH;
        canvas.height = video.videoHeight * scaleSize;

        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        // Hapus memori URL sementara agar RAM tidak bocor
        URL.revokeObjectURL(video.src);
        resolve(canvas.toDataURL('image/jpeg', 0.6));
      };

      // Kalau format video tidak didukung atau rusak
      video.onerror = () => {
        URL.revokeObjectURL(video.src);
        resolve(null); // Kembalikan null, nanti di UI muncul ikon 📄
      };
      return; // Stop di sini kalau video
    }

    // --- CABANG 3: KALAU FILE ADALAH PDF ---
    if (file.type.includes('pdf')) {
      file.arrayBuffer().then(async (arrayBuffer) => {
          // ... isinya tetap sama
        try {
          const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
          const pdf = await loadingTask.promise;
          const page = await pdf.getPage(1); // Tarik halaman 1

          const viewport = page.getViewport({ scale: 1.0 });
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');

          // Kalkulasi biar lebarnya 100px
          const MAX_WIDTH = 100;
          const scaleSize = MAX_WIDTH / viewport.width;
          const scaledViewport = page.getViewport({ scale: scaleSize });

          canvas.width = scaledViewport.width;
          canvas.height = scaledViewport.height;

          await page.render({
            canvasContext: ctx,
            viewport: scaledViewport
          }).promise;

          resolve(canvas.toDataURL('image/jpeg', 0.6));
        } catch (error) {
          console.error("Gagal membaca PDF:", error);
          resolve(null); // Gagal render, balikin null biar jadi ikon 📄
        }
      });
      return; // Stop di sini kalau PDF
    }

    // --- CABANG 4: KALAU FORMAT LAIN (DOCX, ZIP, dll) ---
    resolve(null);

  });
}

// 4. Enkripsi Teks (Khusus untuk mengamankan String Base64 Thumbnail)
export async function encryptText(text, password) {
  if (!text) return null;
  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(password, salt);
  
  const encodedText = new TextEncoder().encode(text);
  const encryptedContent = await window.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv }, 
    key, 
    encodedText
  );
  
  const combinedBuffer = new Uint8Array(16 + 12 + encryptedContent.byteLength);
  combinedBuffer.set(salt, 0);
  combinedBuffer.set(iv, 16);
  combinedBuffer.set(new Uint8Array(encryptedContent), 16 + 12);
  
  // Ubah hasil biner menjadi teks Base64 agar mudah disimpan di MariaDB
  let binary = '';
  combinedBuffer.forEach((b) => binary += String.fromCharCode(b));
  return window.btoa(binary);
}

// 5. Dekripsi Teks (Membuka gembok Thumbnail di Dashboard)
export async function decryptText(encryptedBase64, password) {
  if (!encryptedBase64) return null;
  try {
    const binary = window.atob(encryptedBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    
    const salt = bytes.slice(0, 16);
    const iv = bytes.slice(16, 28);
    const data = bytes.slice(28);
    
    const key = await deriveKey(password, salt);
    const decryptedContent = await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv }, 
      key, 
      data
    );
    return new TextDecoder().decode(decryptedContent);
  } catch (e) {
    // Kalau password salah, kembalikan null (gambar tetap ikon gembok)
    return null; 
  }
}

// 6. Dekripsi File Biner (.bin kembali ke file asli saat Download)
export async function decryptFile(encryptedBlob, password) {
  try {
    const arrayBuffer = await encryptedBlob.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    
    // Potong file untuk misahkan Salt, IV, dan File Utama
    const salt = bytes.slice(0, 16);
    const iv = bytes.slice(16, 28);
    const encryptedData = bytes.slice(28);
    
    // Racik ulang DNA kunci kriptografinya
    const key = await deriveKey(password, salt);
    
    // Eksekusi hukum matematika AES-GCM (akan crash kalau kunci beda)
    const decryptedBuffer = await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv },
      key,
      encryptedData
    );
    
    // Kembalikan dalam bentuk Blob mentah yang siap diunduh
    return new Blob([decryptedBuffer]);
  } catch (e) {
    throw new Error("Gagal melakukan dekripsi! Password salah atau file rusak.");
  }
}
